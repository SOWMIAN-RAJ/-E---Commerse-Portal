// Code will be large; we reuse from canvas
import React from 'react';
export default function ECommercePortal(){return(<div>Portal Loaded</div>)}