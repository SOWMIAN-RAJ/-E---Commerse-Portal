# E-Commerce Portal

A demo **E-Commerce Web Application** built using **React** and **Tailwind CSS**.

## 👤 Author
**T. Sowmian Raj**

## ✨ Features
- Navigation Menu (Home, Products, Contact Us, About Us)
- User Registration and Login (with input validation)
- Orders List & Wishlist management
- Product Reviews and Comments
- Customer Care Form and Reporting options
- LocalStorage data persistence

## 🛠️ Technologies
- React 18
- Tailwind CSS 3
- JavaScript (ES6)
- HTML5, CSS3

## 🚀 Run Locally
```bash
npm install
npm start
```

Then open http://localhost:3000

## 🧰 Build for Production
```bash
npm run build
```

## 🌐 Deploy on GitHub Pages / Netlify
Upload the build folder to your chosen hosting platform.

---
> 💡 Created as an assignment project for learning purposes.
